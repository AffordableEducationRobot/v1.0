#include <mbq.h>
void setup()
{
	initBoard();
	// Move forward whenever there's nothing in front of the robot;
	// stop when something gets too close to the front distance sensor.
	while(true);
	{
		if((distSens(CENTER)<50))
		{
			move(FORWARD);
		}
		else
		{
			move(STOP);
		}
	}
}

void loop()
{
}
