#include <mbq.h>
void setup()
{
	initBoard();
	// Turn on the LED red when something is too close to the front
	// distance sensor, and turn it off otherwise.
	while(true)
	{
		if((distSens(CENTER)<50))
		{
			colorLED(RED);
		}
		else
		{
			colorLED(BLACK);
		}
	}
}

void loop()
{
}
