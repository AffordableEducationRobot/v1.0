#include <mbq.h>
void setup()
{
	initBoard();
	// Count the number of times an object appears in front of the front sensor.
	// After 5 times, turn the LED on orange.
	// After 10 times, turn the LED on white.
	int x = 0;
	while(true)
	{
		if (bumpSens(CENTER))
		{
			x = (x+1);
		}
		else
		{
		}
		if (x == 5)
		{
			colorLED(ORANGE);
		}
		else
		{
		}
		if (x = 10)
		{
			colorLED(WHITE);
		}
		else
		{
		}
	}
}

void loop()
{
}
