#include <mbq.h>
void setup()
{
	initBoard();
	float left_bumper = (bumpSens(LEFT));
	float right_bumper = (bumpSens(RIGHT));
	float front_bumper = (bumpSens(CENTER));
	//Bump-and-turn
	while(true)
	{
		move(FORWARD);
		left_bumper = (bumpSens(LEFT));
		right_bumper = (bumpSens(RIGHT));
		front_bumper = (bumpSens(CENTER));
		if((left_bumper!=0))
		{
			move(TURN_RIGHT);
			Delay(1);
		}
		else
		{
		        if((right_bumper!=0))
			{
				move(TURN_LEFT);
				Delay(1);
			}
			else
			{
			        if((front_bumper!=0))
				{
					move(BACKWARD);
					Delay(1);
				}
				else
				{
				}
			}
		}
	}
}

void loop()
{
}
