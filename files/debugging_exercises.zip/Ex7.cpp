#include <mbq.h>
void setup()
{
	initBoard();
	// Travel in a square to the right, then a square to the left,
	// then repeat both squares again.
	for(unsigned int i=1; i<(unsigned int)(2); i++)
	{
		for(unsigned int j=0; j<=(unsigned int)(4); j++)
		{
			move(FORWARD);
			Delay(1);
			move(TURN_RIGHT);
			Delay(4);
		}
		for(unsigned int k=1; k<=(unsigned int)(4); k++)
		{
			move(FORWARD);
			Delay(1);
			move(TURN_LEFT);
			Delay(4);
		}
	}
}

void loop()
{
}
