#include <mbq.h>
void setup()
{
	initBoard();
	//Bump-and-turn
	while(true)
	{
		mov(FORWARD);
		left_bumper = (bumpSens(LEFT));
		right_bumper = (bumpSens(RIGHT));
		front_bumper = (bumpSens(CENTER));
		if((left_bumper!=0))
		{
			move(TURN_RIGHT);
			delay(1);
		else
		{
		        if right_bumper!=0
			{
				move(TURN_LEFT)
				Delay(1)
			}
			else
			{
			        if((front-bumper!=0))
				{
					move(BACK);
					Delay(1);
				}
				else
				{
				}
			}
		}
	}
}

void loop()
{
}
